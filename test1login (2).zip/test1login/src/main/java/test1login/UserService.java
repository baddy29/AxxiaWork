package test1login;

public interface UserService {

	public User findUserByName(String name);
	public void saveUser(User user);
}
