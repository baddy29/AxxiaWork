package test1login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Test1loginApplication {

	public static void main(String[] args) {
		SpringApplication.run(Test1loginApplication.class, args);
		System.out.println("Hi.............");
	}
}
